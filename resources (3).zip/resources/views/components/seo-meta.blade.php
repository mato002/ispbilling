@props([
    'title' => null,
    'description' => null,
    'image' => null,
    'canonical' => null,
    'robots' => 'index, follow',
    'ogType' => 'website',
    'keywords' => null,
])

@php
    $appName = config('app.name', 'PrimeBilling');
    $pageTitle = $title ?? ($appName.' · Run your entire ISP from one platform');
    $pageDescription = \Illuminate\Support\Str::limit(
        trim(strip_tags($description ?? config('seo.default_description'))),
        160
    );
    $canonicalUrl = $canonical ?? url()->current();
    $ogImage = $image ?? config('seo.og_image') ?? asset('images/primebilling-mark.svg');
    $pageKeywords = $keywords ?? config('seo.keywords');
@endphp

<title>{{ $pageTitle }}</title>
<meta name="description" content="{{ $pageDescription }}">
@if($pageKeywords)
    <meta name="keywords" content="{{ $pageKeywords }}">
@endif
<meta name="robots" content="{{ $robots }}">
<link rel="canonical" href="{{ $canonicalUrl }}">

<meta property="og:type" content="{{ $ogType }}">
<meta property="og:url" content="{{ $canonicalUrl }}">
<meta property="og:site_name" content="{{ $appName }}">
<meta property="og:title" content="{{ $pageTitle }}">
<meta property="og:description" content="{{ $pageDescription }}">
<meta property="og:image" content="{{ $ogImage }}">
<meta property="og:locale" content="{{ str_replace('_', '-', app()->getLocale()) }}">

<meta name="twitter:card" content="summary_large_image">
@if(config('seo.twitter_handle'))
    <meta name="twitter:site" content="{{ config('seo.twitter_handle') }}">
@endif
<meta name="twitter:title" content="{{ $pageTitle }}">
<meta name="twitter:description" content="{{ $pageDescription }}">
<meta name="twitter:image" content="{{ $ogImage }}">

@if(config('seo.google_site_verification'))
    <meta name="google-site-verification" content="{{ config('seo.google_site_verification') }}">
@endif
@if(config('seo.bing_site_verification'))
    <meta name="msvalidate.01" content="{{ config('seo.bing_site_verification') }}">
@endif

<link rel="icon" href="{{ asset('images/primebilling-mark.svg') }}" type="image/svg+xml">
<meta name="theme-color" content="#2563eb">
