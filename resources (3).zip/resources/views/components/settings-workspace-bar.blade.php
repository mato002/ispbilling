@props([
    'scope' => 'admin',
])

@php
    /** @var \App\Support\Navigation\SettingsWorkspaceNav $nav */
    $nav = app(\App\Support\Navigation\SettingsWorkspaceNav::class);
    $workspaces = $nav->items($scope);
@endphp

@if ($workspaces !== [])
    <nav
        class="pb-settings-workspace pb-fade-up mb-6"
        aria-label="{{ __('Settings workspaces') }}"
    >
        <div class="pb-settings-workspace__scroll">
            @foreach ($workspaces as $item)
                @php
                    $isActive = $nav->isActive($item);
                    $href = route($item['route']);
                @endphp
                <a
                    href="{{ $href }}"
                    data-turbo-frame="pb-main"
                    data-turbo-action="advance"
                    @class([
                        'pb-settings-workspace__tab',
                        'is-active' => $isActive,
                    ])
                    @if ($isActive) aria-current="page" @endif
                >
                    {{ $item['label'] }}
                </a>
            @endforeach
        </div>
    </nav>
@endif
