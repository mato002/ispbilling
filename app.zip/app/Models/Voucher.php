<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;
use Carbon\Carbon;

class Voucher extends Model
{
    protected $fillable = [
        'isp_id',
        'router_id',
        'plan_id',
        'created_by',
        'voucher_code',
        'voucher_type', // 'time' or 'data'
        'time_limit_hours',
        'data_limit_mb',
        'speed_profile',
        'price',
        'status', // 'active', 'used', 'expired', 'cancelled'
        'expires_at',
        'used_by',
        'assigned_to', // Pre-assigned to customer
        'used_at',
        'notes',
        'metadata',
    ];

    protected $casts = [
        'expires_at' => 'datetime',
        'used_at' => 'datetime',
        'time_limit_hours' => 'integer',
        'data_limit_mb' => 'integer',
        'price' => 'decimal:2',
        'metadata' => 'array',
    ];

    public function isp(): BelongsTo
    {
        return $this->belongsTo(ISP::class, 'isp_id');
    }

    public function router(): BelongsTo
    {
        return $this->belongsTo(Router::class, 'router_id');
    }

    public function plan(): BelongsTo
    {
        return $this->belongsTo(Plan::class, 'plan_id');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function usedByCustomer(): BelongsTo
    {
        return $this->belongsTo(Customer::class, 'used_by');
    }

    public function assignedToCustomer(): BelongsTo
    {
        return $this->belongsTo(Customer::class, 'assigned_to');
    }

    public function payment(): BelongsTo
    {
        return $this->belongsTo(Payment::class, 'voucher_id');
    }

    /**
     * Check if voucher is valid (active and not expired)
     */
    public function isValid(): bool
    {
        return $this->status === 'active' 
            && ($this->expires_at === null || $this->expires_at->isFuture());
    }

    /**
     * Check if voucher is expired
     */
    public function isExpired(): bool
    {
        return $this->expires_at !== null && $this->expires_at->isPast();
    }

    /**
     * Mark voucher as used
     */
    public function markAsUsed(?int $customerId = null): void
    {
        $this->update([
            'status' => 'used',
            'used_by' => $customerId,
            'used_at' => now(),
        ]);
    }

    /**
     * Mark voucher as expired
     */
    public function markAsExpired(): void
    {
        $this->update(['status' => 'expired']);
    }

    /**
     * Generate unique voucher code
     */
    public static function generateCode(int $length = 12): string
    {
        do {
            $code = strtoupper(Str::random($length));
        } while (self::where('voucher_code', $code)->exists());

        return $code;
    }

    /**
     * Scope to filter by ISP
     */
    public function scopeForIsp($query, $ispId)
    {
        return $query->where('isp_id', $ispId);
    }

    /**
     * Scope to filter active vouchers
     */
    public function scopeActive($query)
    {
        return $query->where('status', 'active')
            ->where(function ($q) {
                $q->whereNull('expires_at')
                  ->orWhere('expires_at', '>', now());
            });
    }

    /**
     * Scope to filter expired vouchers
     */
    public function scopeExpired($query)
    {
        return $query->where(function ($q) {
            $q->where('status', 'expired')
              ->orWhere(function ($q2) {
                  $q2->where('status', 'active')
                     ->whereNotNull('expires_at')
                     ->where('expires_at', '<=', now());
              });
        });
    }

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($voucher) {
            if (empty($voucher->voucher_code)) {
                $voucher->voucher_code = static::generateCode();
            }
        });
    }
}





