<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Router extends Model
{
    protected $fillable = [
        'isp_id',
        'name',
        'ip_address',
        'username',
        'password',
        'port',
        'use_ssl',
        'location',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'use_ssl' => 'boolean',
        'port' => 'integer',
    ];

    protected $hidden = [
        'password',
    ];

    public function isp(): BelongsTo
    {
        return $this->belongsTo(ISP::class, 'isp_id');
    }

    public function customers(): HasMany
    {
        return $this->hasMany(Customer::class, 'router_id');
    }

    public function getApiUrl(): string
    {
        $protocol = $this->use_ssl ? 'https' : 'http';
        return "{$protocol}://{$this->ip_address}:{$this->port}";
    }
}
