<?php

namespace App\Http\Controllers\ISP\Web;

use App\Http\Controllers\Controller;
use App\Models\Router;
use Illuminate\Http\Request;

class RouterController extends Controller
{
    public function index(Request $request)
    {
        $ispId = auth()->user()->isp_id;
        
        $query = Router::where('isp_id', $ispId)->withCount('customers');

        if ($request->has('is_active') && $request->is_active !== '') {
            $query->where('is_active', $request->is_active);
        }

        $routers = $query->latest()->paginate(20);

        return view('isp.routers.index', compact('routers'));
    }

    public function create()
    {
        return view('isp.routers.create');
    }

    public function store(Request $request)
    {
        // Placeholder - will be implemented
        return redirect()->route('isp.routers.index')->with('success', 'Router added successfully');
    }

    public function show(Router $router)
    {
        if ($router->isp_id !== auth()->user()->isp_id) {
            abort(403);
        }
        $router->loadCount('customers');
        return view('isp.routers.show', compact('router'));
    }

    public function edit(Router $router)
    {
        if ($router->isp_id !== auth()->user()->isp_id) {
            abort(403);
        }
        return view('isp.routers.edit', compact('router'));
    }

    public function update(Request $request, Router $router)
    {
        if ($router->isp_id !== auth()->user()->isp_id) {
            abort(403);
        }
        // Placeholder - will be implemented
        return redirect()->route('isp.routers.index')->with('success', 'Router updated successfully');
    }

    /**
     * Activate router
     */
    public function activate(Router $router)
    {
        if ($router->isp_id !== auth()->user()->isp_id) {
            abort(403);
        }

        $router->update(['is_active' => true]);

        return back()->with('success', 'Router activated successfully.');
    }

    /**
     * Deactivate router
     */
    public function deactivate(Router $router)
    {
        if ($router->isp_id !== auth()->user()->isp_id) {
            abort(403);
        }

        $router->update(['is_active' => false]);

        return back()->with('success', 'Router deactivated successfully.');
    }

    /**
     * Test router connection
     */
    public function testConnection(Router $router)
    {
        if ($router->isp_id !== auth()->user()->isp_id) {
            abort(403);
        }

        try {
            $mikrotik = new \App\Services\MikroTikService($router);
            $connected = $mikrotik->connect();

            if ($connected) {
                return back()->with('success', 'Router connection test successful!');
            } else {
                return back()->with('error', 'Failed to connect to router. Please check credentials and network connectivity.');
            }
        } catch (\Exception $e) {
            return back()->with('error', 'Connection test failed: ' . $e->getMessage());
        }
    }
}

