<?php

namespace App\Http\Controllers\ISP\Web;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use Illuminate\Http\Request;
use Carbon\Carbon;

class NotificationController extends Controller
{
    /**
     * Display notifications for the logged-in ISP
     */
    public function index(Request $request)
    {
        $ispId = auth()->user()->isp_id;
        
        if (!$ispId) {
            abort(403, 'Only ISP admins can access notifications');
        }

        $query = Notification::forIsp($ispId);

        // Filter by read status
        if ($request->has('status') && $request->status === 'unread') {
            $query->unread();
        } elseif ($request->has('status') && $request->status === 'read') {
            $query->read();
        }

        // Filter by type
        if ($request->has('type') && $request->type) {
            $query->byType($request->type);
        }

        // Filter by date range
        if ($request->has('date_from') && $request->date_from) {
            $startDate = Carbon::parse($request->date_from)->startOfDay();
            $endDate = $request->has('date_to') && $request->date_to 
                ? Carbon::parse($request->date_to)->endOfDay()
                : Carbon::now()->endOfDay();
            $query->dateRange($startDate, $endDate);
        }

        $notifications = $query->latest()->paginate(20);

        // Get counts for filters
        $unreadCount = Notification::forIsp($ispId)->unread()->count();
        $totalCount = Notification::forIsp($ispId)->count();

        return view('isp.notifications.index', compact('notifications', 'unreadCount', 'totalCount'));
    }

    /**
     * Mark a notification as read
     */
    public function markAsRead(Notification $notification)
    {
        $ispId = auth()->user()->isp_id;
        
        if ($notification->isp_id !== $ispId) {
            abort(403, 'Unauthorized access');
        }

        $notification->markAsRead();

        return response()->json([
            'success' => true,
            'message' => 'Notification marked as read',
        ]);
    }

    /**
     * Mark all notifications as read
     */
    public function markAllRead(Request $request)
    {
        $ispId = auth()->user()->isp_id;
        
        if (!$ispId) {
            abort(403, 'Only ISP admins can access notifications');
        }

        Notification::forIsp($ispId)->unread()->update(['is_read' => true]);

        if ($request->expectsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'All notifications marked as read',
            ]);
        }

        return redirect()->route('isp.notifications.index')
            ->with('success', 'All notifications marked as read');
    }
}
