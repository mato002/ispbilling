<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\ISP;
use App\Models\Customer;
use App\Models\Invoice;
use App\Models\Payment;
use App\Services\MpesaService;

class TestMpesaStk extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'mpesa:test-stk {phone=254728883160} {amount=100} {--isp=1}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Test MPesa STK Push to a phone number';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $phone = $this->argument('phone');
        $amount = (float) $this->argument('amount');
        $ispId = $this->option('isp');

        // Format phone number
        $phone = preg_replace('/^0/', '254', $phone);
        $phone = preg_replace('/[^0-9]/', '', $phone);
        
        if (!preg_match('/^254[0-9]{9}$/', $phone)) {
            $this->error('Invalid phone number format. Use: 254XXXXXXXXX');
            return 1;
        }

        $this->info("Testing MPesa STK Push...");
        $this->info("Phone: {$phone}");
        $this->info("Amount: KES {$amount}");
        
        // Get ISP
        $isp = ISP::find($ispId);
        if (!$isp) {
            $isp = ISP::first();
            if (!$isp) {
                $this->error('No ISP found. Please create an ISP first.');
                return 1;
            }
            $this->warn("ISP not found with ID {$ispId}, using first ISP: {$isp->name}");
        }

        $this->info("ISP: {$isp->name}");

        // Create or get a test customer
        $customer = Customer::where('isp_id', $isp->id)
            ->where('phone_number', $phone)
            ->first();

        if (!$customer) {
            $this->info("Creating test customer...");
            $customer = Customer::create([
                'isp_id' => $isp->id,
                'full_name' => 'Test Customer',
                'phone_number' => $phone,
                'location' => 'Test Location',
                'connection_type' => 'hotspot',
                'password' => bcrypt('test123'),
                'installation_date' => now(),
                'status' => 'active',
            ]);
            $this->info("Customer created: {$customer->username}");
        }

        // Create a test invoice
        $this->info("Creating test invoice...");
        $invoice = Invoice::create([
            'isp_id' => $isp->id,
            'customer_id' => $customer->id,
            'invoice_number' => 'TEST-' . now()->format('YmdHis'),
            'amount' => $amount,
            'tax' => 0,
            'total_amount' => $amount,
            'issue_date' => now(),
            'due_date' => now()->addDays(7),
            'status' => 'pending',
        ]);
        $this->info("Invoice created: {$invoice->invoice_number}");

        // Create payment
        $this->info("Creating payment record...");
        $payment = Payment::create([
            'isp_id' => $isp->id,
            'customer_id' => $customer->id,
            'invoice_id' => $invoice->id,
            'payment_method' => 'mpesa',
            'amount' => $amount,
            'phone_number' => $phone,
            'status' => 'pending',
        ]);
        $this->info("Payment created: {$payment->payment_reference}");

        // Initiate STK Push
        $this->info("\nInitiating STK Push...");
        $mpesaService = new MpesaService($isp);
        $result = $mpesaService->initiateStkPush($payment);

        if ($result['success']) {
            $this->info("✓ STK Push initiated successfully!");
            $this->info("Checkout Request ID: " . ($result['checkout_request_id'] ?? 'N/A'));
            $this->info("\nPlease check your phone ({$phone}) to complete the payment.");
            
            if (isset($result['simulated']) && $result['simulated']) {
                $this->warn("\n⚠ This is a simulated payment (development mode).");
            }
        } else {
            $this->error("✗ STK Push failed!");
            $this->error("Error: " . ($result['message'] ?? 'Unknown error'));
            return 1;
        }

        return 0;
    }
}
