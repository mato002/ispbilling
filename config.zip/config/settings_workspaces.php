<?php

/**
 * Horizontal settings workspace tabs (shown at top of settings pages).
 * Mirrors sidebar Settings sub-navigation; used when the sidebar is collapsed.
 */
return [

    'admin' => [
        [
            'label' => 'General',
            'route' => 'admin.settings.index',
            'active' => ['admin.settings.index'],
        ],
        [
            'label' => 'Form controls',
            'route' => 'admin.settings.forms.index',
            'active' => ['admin.settings.forms.*'],
        ],
        [
            'label' => 'Integrations',
            'route' => 'admin.integrations.index',
            'active' => ['admin.integrations.*'],
        ],
        [
            'label' => 'Portal settings',
            'route' => 'admin.portal-settings.index',
            'active' => ['admin.portal-settings.*'],
        ],
        [
            'label' => 'Security',
            'route' => 'admin.audit.security',
            'active' => ['admin.audit.security'],
        ],
        [
            'label' => 'Promo codes',
            'route' => 'admin.promo-codes.index',
            'active' => ['admin.promo-codes.*'],
        ],
    ],

    'isp' => [
        [
            'label' => 'Operations hub',
            'route' => 'isp.settings.index',
            'active' => ['isp.settings.index'],
        ],
        [
            'label' => 'Company & branding',
            'route' => 'isp.settings.company',
            'active' => ['isp.settings.company*', 'isp.settings.custom-fields*'],
        ],
        [
            'label' => 'Form controls',
            'route' => 'isp.settings.forms.index',
            'active' => ['isp.settings.forms.*'],
        ],
        [
            'label' => 'Payments',
            'route' => 'isp.settings.payment-gateways',
            'active' => [
                'isp.settings.payment*',
                'isp.settings.payment-gateways*',
                'isp.payment-settings.*',
                'isp.settings.billing*',
            ],
        ],
        [
            'label' => 'Users',
            'route' => 'isp.settings.users',
            'active' => ['isp.settings.users*', 'isp.settings.roles*'],
        ],
        [
            'label' => 'Notifications',
            'route' => 'isp.settings.notifications',
            'active' => ['isp.settings.notifications*'],
        ],
        [
            'label' => 'Audit logs',
            'route' => 'isp.logs.activity.index',
            'active' => ['isp.logs.*'],
        ],
    ],

];
