<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Meta Description
    |--------------------------------------------------------------------------
    |
    | Used on public marketing pages when no page-specific description is set.
    |
    */

    'default_description' => env(
        'SEO_DEFAULT_DESCRIPTION',
        'PrimeBilling is the ISP operating system — MikroTik automation, M-Pesa billing, hotspot & PPPoE management, and customer analytics in one platform.'
    ),

    /*
    |--------------------------------------------------------------------------
    | Default Keywords
    |--------------------------------------------------------------------------
    */

    'keywords' => env(
        'SEO_KEYWORDS',
        'ISP billing software, MikroTik billing, M-Pesa ISP payments, hotspot management, PPPoE billing, ISP automation, Kenya ISP software, PrimeBilling'
    ),

    /*
    |--------------------------------------------------------------------------
    | Open Graph Default Image
    |--------------------------------------------------------------------------
    |
    | Absolute URL recommended for social crawlers. Falls back to the app mark.
    |
    */

    'og_image' => env('SEO_OG_IMAGE'),

    /*
    |--------------------------------------------------------------------------
    | Social & Search Console Verification
    |--------------------------------------------------------------------------
    */

    'twitter_handle' => env('SEO_TWITTER_HANDLE'),

    'google_site_verification' => env('SEO_GOOGLE_SITE_VERIFICATION'),

    'bing_site_verification' => env('SEO_BING_SITE_VERIFICATION'),

];
