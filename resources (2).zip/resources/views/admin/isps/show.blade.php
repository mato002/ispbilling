<x-admin-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                {{ __('ISP Details') }}
            </h2>
            <div class="flex space-x-2">
                <a href="{{ route('admin.isps.edit', $isp->id) }}" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                    Edit
                </a>
                <a href="{{ route('admin.isps.index') }}" class="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600">
                    Back to List
                </a>
            </div>
        </div>
    </x-slot>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- ISP Information -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Basic Information -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <h3 class="text-2xl font-semibold text-gray-900 dark:text-gray-100">{{ $isp->name }}</h3>
                            <p class="text-gray-600 dark:text-gray-400 mt-1">{{ $isp->company_name }}</p>
                        </div>
                        <div class="flex flex-col items-end gap-2">
                        @if($isp->is_active)
                            <span class="px-3 py-1 text-sm rounded-full bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">
                                Active
                            </span>
                        @else
                            <span class="px-3 py-1 text-sm rounded-full bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100">
                                Inactive
                            </span>
                        @endif
                        @if($isp->platform_access_locked)
                            <span class="px-3 py-1 text-xs rounded-full bg-amber-100 text-amber-900 dark:bg-amber-900/40 dark:text-amber-100">
                                Dashboard locked (SaaS)
                            </span>
                        @endif
                        </div>
                    </div>

                    @if($isp->platform_access_locked)
                        <div class="mb-4 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-950 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-100">
                            <strong>Operators cannot access the ISP workspace.</strong>
                            @if($isp->platform_access_message)
                                <p class="mt-2">{{ $isp->platform_access_message }}</p>
                            @endif
                        </div>
                    @endif

                    <dl class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                        <div>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Email</dt>
                            <dd class="mt-1 text-sm text-gray-900 dark:text-gray-100">{{ $isp->email }}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Phone</dt>
                            <dd class="mt-1 text-sm text-gray-900 dark:text-gray-100">{{ $isp->phone }}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Address</dt>
                            <dd class="mt-1 text-sm text-gray-900 dark:text-gray-100">{{ $isp->address ?? 'N/A' }}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Currency</dt>
                            <dd class="mt-1 text-sm text-gray-900 dark:text-gray-100">{{ $isp->currency }}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Timezone</dt>
                            <dd class="mt-1 text-sm text-gray-900 dark:text-gray-100">{{ $isp->timezone }}</dd>
                        </div>
                        @php($pb = data_get($isp->settings, 'platform_billing'))
                        @if (is_array($pb) && ! empty($pb))
                            <div class="md:col-span-2">
                                <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Platform billing (onboarding)</dt>
                                <dd class="mt-1 text-sm text-gray-900 dark:text-gray-100">
                                    <span class="font-mono text-xs">Method: {{ $pb['method'] ?? '—' }}</span>
                                    @if (! empty($pb['billing_email']))
                                        <span class="block mt-1">Billing email: {{ $pb['billing_email'] }}</span>
                                    @endif
                                    @if (! empty($pb['bank_name']))
                                        <span class="block mt-1">Bank: {{ $pb['bank_name'] }} — {{ $pb['bank_account_name'] ?? '' }} / {{ $pb['bank_account_number'] ?? '' }}</span>
                                    @endif
                                    @if (! empty($isp->saas_billing_phone))
                                        <span class="block mt-1">M-Pesa billing: {{ $isp->saas_billing_phone }}</span>
                                    @endif
                                </dd>
                            </div>
                        @endif
                        <div>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Public customer portal</dt>
                            <dd class="mt-1 text-sm text-gray-900 dark:text-gray-100">
                                @if($isp->slug && ! in_array(config('app.central_domain'), ['localhost', '127.0.0.1'], true))
                                    <a class="text-blue-600 hover:underline font-mono break-all" target="_blank" rel="noopener"
                                       href="{{ (parse_url(config('app.url'), PHP_URL_SCHEME) ?: 'https').'://'.$isp->slug.'.'.config('app.central_domain') }}">
                                        {{ (parse_url(config('app.url'), PHP_URL_SCHEME) ?: 'https').'://'.$isp->slug.'.'.config('app.central_domain') }}
                                    </a>
                                @else
                                    <span class="text-gray-500">Set a slug and configure APP_CENTRAL_DOMAIN / DNS for tenant URLs.</span>
                                @endif
                            </dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Created</dt>
                            <dd class="mt-1 text-sm text-gray-900 dark:text-gray-100">{{ $isp->created_at->format('M d, Y') }}</dd>
                        </div>
                    </dl>
                </div>
            </div>

            <!-- Statistics -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="flex items-center">
                            <div class="flex-shrink-0 bg-blue-500 rounded-md p-3">
                                <svg class="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Customers</p>
                                <p class="text-2xl font-semibold text-gray-900 dark:text-gray-100">{{ $isp->customers_count }}</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="flex items-center">
                            <div class="flex-shrink-0 bg-green-500 rounded-md p-3">
                                <svg class="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Routers</p>
                                <p class="text-2xl font-semibold text-gray-900 dark:text-gray-100">{{ $isp->routers_count }}</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="flex items-center">
                            <div class="flex-shrink-0 bg-yellow-500 rounded-md p-3">
                                <svg class="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Plans</p>
                                <p class="text-2xl font-semibold text-gray-900 dark:text-gray-100">{{ $isp->plans_count }}</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="flex items-center">
                            <div class="flex-shrink-0 bg-purple-500 rounded-md p-3">
                                <svg class="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Users</p>
                                <p class="text-2xl font-semibold text-gray-900 dark:text-gray-100">{{ $isp->users_count }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            @if ($isp->paymentMethods->isNotEmpty())
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Payment methods (encrypted)</h3>
                        <p class="text-sm text-gray-600 dark:text-gray-400 mb-4">Tenant profiles only — secrets are never shown here.</p>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm">
                                <thead>
                                    <tr>
                                        <th class="py-2 pr-4 text-left font-medium text-gray-500 dark:text-gray-400">Provider</th>
                                        <th class="py-2 pr-4 text-left font-medium text-gray-500 dark:text-gray-400">Status</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                                    @foreach ($isp->paymentMethods as $pm)
                                        <tr>
                                            <td class="py-2 pr-4 font-mono text-xs text-gray-900 dark:text-gray-100">{{ $pm->provider }}</td>
                                            <td class="py-2 pr-4">
                                                @if ($pm->active)
                                                    <span class="text-green-700 dark:text-green-400 font-medium">Active</span>
                                                @else
                                                    <span class="text-gray-500 dark:text-gray-400">Inactive</span>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            @endif
        </div>

        <!-- Sidebar -->
        <div>
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Quick Actions</h3>
                    <div class="space-y-2">
                        @if ($isp->needsSaasOnboarding())
                            <a href="{{ route('admin.isps.saas-onboarding.show', $isp) }}" class="block w-full text-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 text-sm font-medium">
                                Complete SaaS onboarding (on behalf)
                            </a>
                        @endif
                        <a href="{{ route('admin.isps.edit', $isp->id) }}" class="block w-full text-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                            Edit ISP
                        </a>
                        @if($isp->is_active)
                            <form method="POST" action="{{ route('admin.isps.update', $isp->id) }}">
                                @csrf
                                @method('PUT')
                                <input type="hidden" name="is_active" value="0">
                                <button type="submit" class="w-full px-4 py-2 bg-yellow-100 text-yellow-800 rounded-lg hover:bg-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-400">
                                    Deactivate
                                </button>
                            </form>
                        @else
                            <form method="POST" action="{{ route('admin.isps.update', $isp->id) }}">
                                @csrf
                                @method('PUT')
                                <input type="hidden" name="is_active" value="1">
                                <button type="submit" class="w-full px-4 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 dark:bg-green-900/20 dark:text-green-400">
                                    Activate
                                </button>
                            </form>
                            <form method="POST" action="{{ route('admin.isps.force-suspend-network', $isp->id) }}" onsubmit="return confirm('Queue suspension sync on all routers for this ISP? Use when a router was offline during deactivation.');">
                                @csrf
                                <button type="submit" class="w-full px-4 py-2 bg-orange-100 text-orange-900 rounded-lg hover:bg-orange-200 dark:bg-orange-900/30 dark:text-orange-100 text-sm font-medium">
                                    Force sync suspension (routers)
                                </button>
                            </form>
                        @endif
                        <form method="POST" action="{{ route('admin.isps.destroy', $isp->id) }}" onsubmit="confirmFormSubmit(event, {title: 'Delete ISP', text: 'Are you sure you want to delete {{ $isp->name }}? This action cannot be undone.', icon: 'warning', confirmButtonText: 'Yes, delete', confirmButtonColor: '#ef4444'}); return false;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="w-full px-4 py-2 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 dark:bg-red-900/20 dark:text-red-400">
                                Delete ISP
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-admin-layout>

