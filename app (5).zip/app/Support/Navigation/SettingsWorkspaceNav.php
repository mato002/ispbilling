<?php

namespace App\Support\Navigation;

use Illuminate\Support\Arr;

class SettingsWorkspaceNav
{
    public function scopeForCurrentRoute(): ?string
    {
        if (! request()->route()) {
            return null;
        }

        foreach (config('settings_workspaces', []) as $scope => $items) {
            if ($this->routeMatchesAny($items)) {
                return $scope;
            }
        }

        return null;
    }

    /**
     * @return list<array{label: string, route: string, active: list<string>}>
     */
    public function items(string $scope): array
    {
        return config("settings_workspaces.{$scope}", []);
    }

    public function isActive(array $item): bool
    {
        return $this->routeMatchesAny([$item]);
    }

    /**
     * @param  list<array{label: string, route: string, active?: list<string>|string}>  $items
     */
    private function routeMatchesAny(array $items): bool
    {
        foreach ($items as $item) {
            $patterns = Arr::wrap($item['active'] ?? [$item['route'] ?? '']);

            foreach ($patterns as $pattern) {
                if ($pattern !== '' && request()->routeIs($pattern)) {
                    return true;
                }
            }
        }

        return false;
    }
}
